import random
char_list = ['a','e','i','o','u']
random.shuffle(char_list)
print(''.join(char_list))